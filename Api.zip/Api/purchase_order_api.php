<?php
// Enable CORS for development
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Include database connection
require_once 'conn.php';

// Get action from query parameter
$action = $_GET['action'] ?? '';

try {
    switch ($action) {
        case 'purchase_order_details':
            getPurchaseOrderDetails($conn);
            break;
        case 'receive_items':
            receiveItems($conn);
            break;
        case 'suppliers':
            getSuppliers($conn);
            break;
        case 'products':
            getProducts($conn);
            break;
        default:
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
            break;
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

function getPurchaseOrderDetails($conn) {
    $poId = $_GET['po_id'] ?? 0;
    
    if (!$poId) {
        echo json_encode(['success' => false, 'error' => 'Purchase order ID required']);
        return;
    }
    
    // Get header
    $headerQuery = "SELECT 
                     po.*, s.supplier_name
                   FROM tbl_purchase_order_header po
                   JOIN tbl_supplier s ON po.supplier_id = s.supplier_id
                   WHERE po.purchase_header_id = ?";
    $stmt = $conn->prepare($headerQuery);
    $stmt->bind_param("i", $poId);
    $stmt->execute();
    $headerResult = $stmt->get_result();
    $header = $headerResult->fetch_assoc();
    
    if (!$header) {
        echo json_encode(['success' => false, 'error' => 'Purchase order not found']);
        return;
    }
    
    // Get details
    $detailsQuery = "SELECT 
                      pod.*, p.product_name, p.category
                    FROM tbl_purchase_order_dtl pod
                    JOIN tbl_product p ON pod.product_id = p.product_id
                    WHERE pod.purchase_header_id = ?";
    $detailStmt = $conn->prepare($detailsQuery);
    $detailStmt->bind_param("i", $poId);
    $detailStmt->execute();
    $detailsResult = $detailStmt->get_result();
    
    $details = [];
    while ($row = $detailsResult->fetch_assoc()) {
        $details[] = $row;
    }
    
    echo json_encode([
        'success' => true,
        'header' => $header,
        'details' => $details
    ]);
}

function receiveItems($conn) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        echo json_encode(['success' => false, 'error' => 'Invalid input data']);
        return;
    }
    
    // Start transaction
    $conn->begin_transaction();
    
    try {
        // Create receiving header
        $receivingQuery = "INSERT INTO tbl_purchase_receiving_header (purchase_header_id, received_by, delivery_receipt_no, notes, receiving_date, receiving_time) 
                          VALUES (?, ?, ?, ?, CURDATE(), CURTIME())";
        $stmt = $conn->prepare($receivingQuery);
        $stmt->bind_param("iiss", 
            $input['purchase_header_id'], 
            $input['received_by'], 
            $input['delivery_receipt_no'], 
            $input['notes']
        );
        
        if (!$stmt->execute()) {
            throw new Exception('Error creating receiving header: ' . $stmt->error);
        }
        
        $receivingId = $conn->insert_id;
        
        // Process each received item
        foreach ($input['items'] as $item) {
            if ($item['received_qty'] > 0) {
                // Insert receiving detail
                $detailQuery = "INSERT INTO tbl_purchase_receiving_dtl (receiving_id, product_id, ordered_qty, received_qty, unit_price, batch_number, expiration_date) 
                               VALUES (?, ?, ?, ?, ?, ?, ?)";
                $detailStmt = $conn->prepare($detailQuery);
                $detailStmt->bind_param("iiidsss", 
                    $receivingId, 
                    $item['product_id'], 
                    $item['ordered_qty'], 
                    $item['received_qty'], 
                    $item['unit_price'], 
                    $item['batch_number'], 
                    $item['expiration_date']
                );
                
                if (!$detailStmt->execute()) {
                    throw new Exception('Error creating receiving detail: ' . $detailStmt->error);
                }
                
                // Update inventory (if inventory table exists)
                updateInventory($conn, $item['product_id'], $item['received_qty'], $item['unit_price'], $item['batch_number'], $item['expiration_date']);
            }
        }
        
        // Update purchase order delivery status
        updatePurchaseOrderStatus($conn, $input['purchase_header_id']);
        
        // Commit transaction
        $conn->commit();
        
        echo json_encode([
            'success' => true, 
            'message' => 'Items received successfully',
            'receiving_id' => $receivingId
        ]);
        
    } catch (Exception $e) {
        // Rollback transaction on error
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
}

function updateInventory($conn, $productId, $quantity, $unitPrice, $batchNumber, $expirationDate) {
    // Check if inventory table exists and update accordingly
    // This is a simplified version - you may need to adjust based on your actual inventory structure
    
    // For now, we'll just log the inventory update
    $logQuery = "INSERT INTO inventory_log (product_id, quantity, unit_price, batch_number, expiration_date, action, log_date) 
                 VALUES (?, ?, ?, ?, ?, 'received', NOW())";
    $stmt = $conn->prepare($logQuery);
    $stmt->bind_param("iidss", $productId, $quantity, $unitPrice, $batchNumber, $expirationDate);
    $stmt->execute();
}

function updatePurchaseOrderStatus($conn, $purchaseOrderId) {
    // After receiving items, mark for review rather than shipped
    $query = "UPDATE tbl_purchase_order_header SET status = 'to_review' WHERE purchase_header_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $purchaseOrderId);
    $stmt->execute();
}

function getSuppliers($conn) {
    $query = "SELECT supplier_id, supplier_name, supplier_contact FROM tbl_supplier WHERE status = 'active' ORDER BY supplier_name";
    $result = $conn->query($query);
    
    if (!$result) {
        echo json_encode(['success' => false, 'error' => 'Database error: ' . $conn->error]);
        return;
    }
    
    $suppliers = [];
    while ($row = $result->fetch_assoc()) {
        $suppliers[] = $row;
    }
    
    echo json_encode(['success' => true, 'data' => $suppliers]);
}

function getProducts($conn) {
    $query = "SELECT product_id, product_name, category, brand, srp as unit_price FROM tbl_product WHERE status = 'active' ORDER BY product_name";
    $result = $conn->query($query);
    
    if (!$result) {
        echo json_encode(['success' => false, 'products' => []]);
        return;
    }
    
    $products = [];
    while ($row = $result->fetch_assoc()) {
        $products[] = $row;
    }
    
    echo json_encode(['success' => true, 'data' => $products]);
}

$conn->close();
?>
