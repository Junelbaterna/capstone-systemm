<?php
// Enable CORS for development
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Include database connection
require_once 'conn.php';

// Get action from query parameter
$action = $_GET['action'] ?? '';

try {
    switch ($action) {
        case 'suppliers':
            getSuppliers($conn);
            break;
        case 'products':
            getProducts($conn);
            break;
        case 'create_purchase_order':
            createPurchaseOrder($conn);
            break;
        case 'purchase_orders':
            getPurchaseOrders($conn);
            break;
        case 'purchase_order_details':
            getPurchaseOrderDetails($conn);
            break;
        case 'approve_purchase_order':
            approvePurchaseOrder($conn);
            break;
        case 'update_delivery_status':
            updateDeliveryStatus($conn);
            break;
        case 'update_po_status':
            updatePurchaseOrderStatus($conn);
            break;
        case 'receiving_list':
            getReceivingList($conn);
            break;
        default:
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
            break;
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

function getSuppliers($conn) {
    try {
        $query = "SELECT supplier_id, supplier_name, supplier_contact FROM tbl_supplier WHERE status = 'active' ORDER BY supplier_name";
        $stmt = $conn->prepare($query);
        $stmt->execute();
        
        $suppliers = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode(['success' => true, 'data' => $suppliers]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Database error: ' . $e->getMessage()]);
    }
}

function getProducts($conn) {
    try {
        $query = "SELECT MIN(product_id) as product_id, product_name, category, MIN(srp) as unit_price 
                  FROM tbl_product 
                  WHERE status = 'active' 
                  GROUP BY product_name, category 
                  ORDER BY product_name";
        $stmt = $conn->prepare($query);
        $stmt->execute();
        
        $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode(['success' => true, 'data' => $products]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Database error: ' . $e->getMessage()]);
    }
}

function createPurchaseOrder($conn) {
    // Get JSON input
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        echo json_encode(['success' => false, 'error' => 'Invalid input data']);
        return;
    }
    
    // Start transaction
    $conn->beginTransaction();
    
    try {
        // Insert purchase order header
        // Align with new DB enum: unpaid | to_ship | shipped | to_review | return
        $headerQuery = "INSERT INTO tbl_purchase_order_header (supplier_id, total_amount, expected_delivery_date, created_by, status, date, time) 
                       VALUES (?, ?, ?, ?, 'unpaid', CURDATE(), CURTIME())";
        $stmt = $conn->prepare($headerQuery);
        $stmt->execute([
            $input['supplier_id'], 
            $input['total_amount'], 
            $input['expected_delivery_date'], 
            $input['created_by']
        ]);
        
        $purchaseHeaderId = $conn->lastInsertId();
        
        // Insert purchase order details
        // Accept either 'products' (from UI) or 'items'
        $details = [];
        if (isset($input['products']) && is_array($input['products'])) {
            $details = $input['products'];
        } elseif (isset($input['items']) && is_array($input['items'])) {
            $details = $input['items'];
        }

        if (!empty($details)) {
            // Match DB columns: quantity + price
            $detailQuery = "INSERT INTO tbl_purchase_order_dtl (purchase_header_id, product_id, quantity, price) VALUES (?, ?, ?, ?)";
            $detailStmt = $conn->prepare($detailQuery);
            foreach ($details as $item) {
                $productId = $item['product_id'];
                $qty = $item['quantity'];
                $unitPrice = $item['unit_price'] ?? ($item['price'] ?? 0);
                $detailStmt->execute([$purchaseHeaderId, $productId, $qty, $unitPrice]);
            }
        }
        
        // Commit transaction
        $conn->commit();
        
        echo json_encode([
            'success' => true, 
            'message' => 'Purchase order created successfully',
            'purchase_order_id' => $purchaseHeaderId
        ]);
        
    } catch (Exception $e) {
        // Rollback transaction on error
        $conn->rollBack();
        echo json_encode(['success' => false, 'error' => 'Error creating purchase order: ' . $e->getMessage()]);
    }
}

function getPurchaseOrders($conn) {
    try {
        $query = "SELECT 
                    po.purchase_header_id,
                    po.po_number,
                    po.total_amount,
                    po.expected_delivery_date,
                    po.status,
                    po.date,
                    s.supplier_name,
                    COALESCE(pod.delivery_status, 'pending') AS delivery_status
                  FROM tbl_purchase_order_header po
                  JOIN tbl_supplier s ON po.supplier_id = s.supplier_id
                  LEFT JOIN tbl_purchase_order_delivery pod ON pod.purchase_header_id = po.purchase_header_id
                  ORDER BY po.date DESC";
        
        $stmt = $conn->prepare($query);
        $stmt->execute();
        $purchaseOrders = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode(['success' => true, 'data' => $purchaseOrders]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Database error: ' . $e->getMessage()]);
    }
}

function getPurchaseOrderDetails($conn) {
    $poId = $_GET['po_id'] ?? 0;
    
    if (!$poId) {
        echo json_encode(['success' => false, 'error' => 'Purchase order ID is required']);
        return;
    }
    
    try {
        // Get header information
        $headerQuery = "SELECT 
                         po.*, s.supplier_name, s.supplier_contact
                       FROM tbl_purchase_order_header po
                       JOIN tbl_supplier s ON po.supplier_id = s.supplier_id
                       WHERE po.purchase_header_id = ?";
        $stmt = $conn->prepare($headerQuery);
        $stmt->execute([$poId]);
        $header = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$header) {
            echo json_encode(['success' => false, 'error' => 'Purchase order not found']);
            return;
        }
        
        // Get detail information
        $detailQuery = "SELECT 
                         pod.*, p.product_name, p.category
                       FROM tbl_purchase_order_dtl pod
                       JOIN tbl_product p ON pod.product_id = p.product_id
                       WHERE pod.purchase_header_id = ?";
        $detailStmt = $conn->prepare($detailQuery);
        $detailStmt->execute([$poId]);
        $details = $detailStmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode([
            'success' => true,
            'header' => $header,
            'details' => $details
        ]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Database error: ' . $e->getMessage()]);
    }
}

function approvePurchaseOrder($conn) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        echo json_encode(['success' => false, 'error' => 'Invalid input data']);
        return;
    }
    
    try {
        $query = "INSERT INTO tbl_purchase_order_approval (purchase_header_id, approved_by, approval_date, approval_status, approval_notes) 
                  VALUES (?, ?, NOW(), ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->execute([
            $input['purchase_header_id'],
            $input['approved_by'], 
            $input['approval_status'],
            $input['approval_notes']
        ]);
        // Reflect approval into header lifecycle status
        if ($input['approval_status'] === 'approved') {
            // After approval, consider order paid -> move to to_ship
            $conn->prepare("UPDATE tbl_purchase_order_header SET status = 'to_ship' WHERE purchase_header_id = ?")
                 ->execute([$input['purchase_header_id']]);
        } elseif ($input['approval_status'] === 'rejected') {
            $conn->prepare("UPDATE tbl_purchase_order_header SET status = 'return' WHERE purchase_header_id = ?")
                 ->execute([$input['purchase_header_id']]);
        }
        
        echo json_encode(['success' => true, 'message' => 'Purchase order updated successfully']);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Error updating purchase order: ' . $e->getMessage()]);
    }
}

function updateDeliveryStatus($conn) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        echo json_encode(['success' => false, 'error' => 'Invalid input data']);
        return;
    }
    
    try {
        $query = "INSERT INTO tbl_purchase_order_delivery (purchase_header_id, expected_delivery_date, actual_delivery_date, delivery_status) 
                  VALUES (?, ?, ?, ?) 
                  ON DUPLICATE KEY UPDATE 
                  actual_delivery_date = VALUES(actual_delivery_date), 
                  delivery_status = VALUES(delivery_status)";
        $stmt = $conn->prepare($query);
        $stmt->execute([
            $input['purchase_header_id'],
            $input['expected_delivery_date'] ?? date('Y-m-d'),
            $input['actual_delivery_date'], 
            $input['delivery_status']
        ]);
        // Sync header lifecycle status with delivery updates (new DB enum)
        if ($input['delivery_status'] === 'delivered') {
            // After confirming delivery, move PO to 'to_review' until explicitly approved
            $conn->prepare("UPDATE tbl_purchase_order_header SET status = 'to_review' WHERE purchase_header_id = ?")
                 ->execute([$input['purchase_header_id']]);
        } elseif ($input['delivery_status'] === 'in_transit' || $input['delivery_status'] === 'partial') {
            $conn->prepare("UPDATE tbl_purchase_order_header SET status = 'to_ship' WHERE purchase_header_id = ?")
                 ->execute([$input['purchase_header_id']]);
        } elseif ($input['delivery_status'] === 'cancelled') {
            $conn->prepare("UPDATE tbl_purchase_order_header SET status = 'return' WHERE purchase_header_id = ?")
                 ->execute([$input['purchase_header_id']]);
        }
        
        echo json_encode(['success' => true, 'message' => 'Delivery status updated successfully']);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Error updating delivery status: ' . $e->getMessage()]);
    }
}

/**
 * Update purchase order header lifecycle status.
 * Used by UI to mark orders as "Unpaid" or "Paid" (mapped to lifecycle states).
 */
function updatePurchaseOrderStatus($conn) {
    $input = json_decode(file_get_contents('php://input'), true);

    if (!$input) {
        echo json_encode(['success' => false, 'error' => 'Invalid input data']);
        return;
    }

    $poId = $input['purchase_header_id'] ?? null;
    $status = $input['status'] ?? '';

    if (!$poId || $status === '') {
        echo json_encode(['success' => false, 'error' => 'purchase_header_id and status are required']);
        return;
    }

    // Map UI to DB enum (support legacy synonyms for backwards compatibility)
    $statusMap = [
        // New values (preferred)
        'unpaid' => 'unpaid',
        'to_ship' => 'to_ship',
        'shipped' => 'shipped',
        'to_review' => 'to_review',
        'return' => 'return',
        // Legacy values accepted and mapped to new ones
        'pending' => 'unpaid',
        'indelivery' => 'to_ship',
        'delivered' => 'shipped',
    ];

    if (!isset($statusMap[$status])) {
        echo json_encode(['success' => false, 'error' => 'Invalid status value']);
        return;
    }
    $status = $statusMap[$status];

    try {
        $stmt = $conn->prepare("UPDATE tbl_purchase_order_header SET status = ? WHERE purchase_header_id = ?");
        $stmt->execute([$status, $poId]);
        echo json_encode(['success' => true, 'message' => 'Purchase order status updated']);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Error updating status: ' . $e->getMessage()]);
    }
}

function getReceivingList($conn) {
    try {
        $query = "SELECT 
                    po.purchase_header_id,
                    po.po_number,
                    po.expected_delivery_date,
                    po.total_amount,
                    COALESCE(pod.delivery_status, 'pending') AS delivery_status,
                    s.supplier_name
                  FROM tbl_purchase_order_header po
                  JOIN tbl_supplier s ON po.supplier_id = s.supplier_id
                  LEFT JOIN tbl_purchase_order_delivery pod ON pod.purchase_header_id = po.purchase_header_id
                  WHERE po.status IN ('to_ship','shipped')
                  ORDER BY po.expected_delivery_date ASC";
        
        $stmt = $conn->prepare($query);
        $stmt->execute();
        $receivingList = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode(['success' => true, 'data' => $receivingList]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Database error: ' . $e->getMessage()]);
    }
}
?>
